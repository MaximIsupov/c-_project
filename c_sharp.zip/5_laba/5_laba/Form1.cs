﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5_laba
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int red = 20, gre = 250, blu = 150;
        int move_count = 0;
        int move_value = 10;
        int timer2_value = 1;
        int timer2_count;

        private void button1_Click(object sender, EventArgs e) // Кнопка "нарисовать Круг"
        {
            int x1 = int.Parse(x1_field.Text);
            int width = int.Parse(width_field.Text);
            int y1 = int.Parse(y1_field.Text);
            int height = int.Parse(height_field.Text);
            draw_ellipse(x1, y1, width, height);
        }

        private void draw_ellipse(int x1, int y1, int width, int height)
        {
            Pen p;
            Graphics g = CreateGraphics();
            g.Clear(Color.White);
            Color clr = new Color();
            int k = 1;
            clr = Color.FromArgb((int)(k * red), (int)(k * gre), (int)(k * blu));
            p = new Pen(clr);
            g.DrawEllipse(p, x1, y1, width, height);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            move_count++;
            int x1 = int.Parse(x1_field.Text)+move_value;
            x1_field.Text = String.Concat(x1);
            int width = int.Parse(width_field.Text);
            int y1 = int.Parse(y1_field.Text);
            int height = int.Parse(height_field.Text);
            draw_ellipse(x1, y1, width, height);
            if (move_count == 25)
            {
                move_count = 0;
                move_value = -move_value;
            }
        }

        private void button4_Click(object sender, EventArgs e)  // Кнопка "Сменить цвет"
        {
            red = int.Parse(red_field.Text);
            gre = int.Parse(green_field.Text);
            blu = int.Parse(blue_field.Text);
            int x1 = int.Parse(x1_field.Text);
            int width = int.Parse(width_field.Text);
            int y1 = int.Parse(y1_field.Text);
            int height = int.Parse(height_field.Text);
            draw_ellipse(x1, y1, width, height);
        }

        private void button5_Click(object sender, EventArgs e)  // Кнопка "Нарисовать прямоугольник"
        {
            int x1 = int.Parse(x1_field.Text);
            int width = int.Parse(width_field.Text);
            int y1 = int.Parse(y1_field.Text);
            int height = int.Parse(height_field.Text);
            Pen p;
            Graphics g = CreateGraphics();
            g.Clear(Color.White);
            Color clr = new Color();
            int k = 1;
            clr = Color.FromArgb((int)(k * red), (int)(k * gre), (int)(k * blu));
            p = new Pen(clr);
            g.DrawRectangle(p, x1, y1, width, height);
        }

        private void button10_Click(object sender, EventArgs e) // Кнопка "Нарисовать линию"
        {
            int x1 = int.Parse(x1_field.Text);
            int width = int.Parse(width_field.Text);
            int y1 = int.Parse(y1_field.Text);
            int height = int.Parse(height_field.Text);
            Pen p;
            Graphics g = CreateGraphics();
            g.Clear(Color.White);
            Color clr = new Color();
            int k = 1;
            clr = Color.FromArgb((int)(k * red), (int)(k * gre), (int)(k * blu));
            p = new Pen(clr);
            g.DrawLine(p, x1, y1, height, width);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2_count++;
            int width = int.Parse(width_field.Text) + timer2_value;
            int height = int.Parse(height_field.Text) + timer2_value;
            int x1 = int.Parse(x1_field.Text);
            int y1 = int.Parse(y1_field.Text);
            width_field.Text = String.Concat(width);
            height_field.Text = String.Concat(height);
            draw_ellipse(x1, y1, width, height);
            if (timer2_count == 50)
            {
                timer2.Stop();
            }
        }

        private void button6_Click(object sender, EventArgs e) 
        {
            timer2_value = 1;
            timer2_count = 0;
            if (timer2.Enabled)
            {
                timer2.Stop();
            }
            else
            { 
                timer2.Start();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            timer2_value = -1;
            timer2_count = 0;
            if (timer2.Enabled)
            {
                timer2.Stop();
            }
            else
            {
                timer2.Start();
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            int mouseX = e.X + 150;
            int mouseY = e.Y;
            int x1 = int.Parse(x1_field.Text);
            if (mouseX < 500) { x1_field.Value = mouseX; x1 = mouseX; }
            int width = int.Parse(width_field.Text);
            int y1 = mouseY;
            y1_field.Value = y1;
            int height = int.Parse(height_field.Text);
            draw_ellipse(x1, y1, width, height);
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.End)
            {
                int x1 = int.Parse(x1_field.Text);
                int width = int.Parse(width_field.Text);
                int y1 = int.Parse(y1_field.Text) + 1;
                y1_field.Value = y1;
                int height = int.Parse(height_field.Text);
                draw_ellipse(x1, y1, width, height);
            }
        }

        private void button1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S)
            {
                int x1 = int.Parse(x1_field.Text);
                int width = int.Parse(width_field.Text);
                int y1 = int.Parse(y1_field.Text) + 10;
                y1_field.Value = y1;
                int height = int.Parse(height_field.Text);
                draw_ellipse(x1, y1, width, height);
            }
            if (e.KeyCode == Keys.W)
            {
                int x1 = int.Parse(x1_field.Text);
                int width = int.Parse(width_field.Text);
                int y1 = int.Parse(y1_field.Text) - 10;
                y1_field.Value = y1;
                int height = int.Parse(height_field.Text);
                draw_ellipse(x1, y1, width, height);
            }
            if (e.KeyCode == Keys.A)
            {
                int x1 = int.Parse(x1_field.Text) - 10;
                int width = int.Parse(width_field.Text);
                int y1 = int.Parse(y1_field.Text);
                x1_field.Value = x1;
                int height = int.Parse(height_field.Text);
                draw_ellipse(x1, y1, width, height);
            }
            if (e.KeyCode == Keys.D)
            {
                int x1 = int.Parse(x1_field.Text) + 10;
                int width = int.Parse(width_field.Text);
                int y1 = int.Parse(y1_field.Text);
                x1_field.Value = x1;
                int height = int.Parse(height_field.Text);
                draw_ellipse(x1, y1, width, height);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }
    }
}
