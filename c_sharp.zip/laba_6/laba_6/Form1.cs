﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            myColor = Color.Red;
            width = 10;
            height = 10;
        }

        private int width;

        private int height;

        private Color myColor;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics dc = e.Graphics;
            Pen myPen = new Pen(myColor);
            dc.DrawRectangle(myPen, 50, 50, width, height);
        }

        private void большойToolStripMenuItem_Click(object sender, EventArgs e)
        {
            width = 100;
            height = 100;
            Invalidate();
        }

        private void маленькийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            width = 10;
            height = 10;
            Invalidate();
        }

        private void красныйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            myColor = Color.Red;
            Invalidate();
        }

        private void синийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            myColor = Color.Blue;
            Invalidate();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            Point myPoint = new Point(e.X, e.Y);
            if ((e.Button.ToString() == "Right") & (myPoint.X < width + 50) & (myPoint.Y < height + 50)
                & (myPoint.X > 50) & (myPoint.Y > 50))
                contextMenuStrip1.Show(this, myPoint);
        }

        private void среднийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            width = 50;
            height = 50;
            Invalidate();
        }

        private void зелёныйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            myColor = Color.Green;
            Invalidate();
        }
    }
}
